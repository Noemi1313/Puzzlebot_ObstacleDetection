#!/usr/bin/env python

# Node to move the turtle by changing the linear velocity in x
# Noemi Carolina Guerra Montiel A00826944

import rospy
from geometry_msgs.msg import Twist
import sys

def move_turtle(line_vel):
	# Initializa a new node: turtlemove
	rospy.init_node('turtlemove', anonymous=True)
	# Publish a Twist msg to topic cmd_vel
	pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
	# 100 Hz
	rate = rospy.Rate(100)

	vel = Twist()
	while True:
		# Change linear velocity in x
		vel.linear.x = line_vel
		vel.linear.y = 0
		vel.linear.z = 0
		vel.angular.x = 0
		vel.angular.y = 0
		vel.angular.z = 0

		rospy.loginfo("Linear Velocity is --> %f", line_vel)
		
		# Publish the input linear velocity
		pub.publish(vel)
		rate.sleep()

if __name__ == '__main__':
	try:
		# The command in terminal must include a value with the input velocity at the end
		move_turtle(float(sys.argv[1]))
	except rospy.ROSInterruptException:
		pass
