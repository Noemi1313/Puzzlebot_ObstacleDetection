#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

import roslib
roslib.load_manifest('practica3')
import sys
import rospy
import cv2
from std_msgs.msg import String
from sensor_msgs.msg import Image
from sensor_msgs.msg import Imu
from cv_bridge import CvBridge, CvBridgeError
import numpy as np

class image_converter:

  def __init__(self):
    self.image_pub = rospy.Publisher("topico_cam",Image, queue_size=10)
    self.str1 = ""
    self.str2 = ""
    self.rate = rospy.Rate(100)
    

    self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber("/camera/image_raw",Image,self.callback)
    self.imu_sub = rospy.Subscriber("/imu", Imu, self.imu)
    rospy.spin()

  def imu(self, data):
    imu = Imu()
    orient = [] 
    accel =  [] 
    imu = data
    #Orientations
    OriX = str(round(imu.orientation.x, 2))
    OriY = str(round(imu.orientation.y, 2))
    OriZ = str(round(imu.orientation.z, 2))
    orient.append(OriX)
    orient.append(OriY)
    orient.append(OriZ)

    #Linear Acceleration
    AccX = str(round(imu.linear_acceleration.x, 2))
    AccY = str(round(imu.linear_acceleration.y, 2))
    AccZ = str(round(imu.linear_acceleration.z, 2))
    accel.append(AccX)
    accel.append(AccY)
    accel.append(AccZ)

    self.str1 = "Aceleracion lineal: "
    self.str2 = "Orientacion: "

    #Convertir la lista en un solo string
    # String de aceleracion
    for ele in accel: 
        self.str1 += ele  
        self.str1 += " " 

    # String de orientacion
    for ele2 in orient: 
        self.str2 += ele2 
        self.str2 += " "  
    
  def callback(self,data):
    try:
      cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      print(e)

    (rows,cols,channels) = cv_image.shape
    if cols > 60 and rows > 60 :
      cv2.circle(cv_image, (50,50), 10, 255)

    #Convert the BGR image to HSV colour space
    hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
    
    #Set the lower and upper bounds for the red hue
    lower = np.array([0,220,50])
    upper = np.array([0,255,255])
        
    #Create a mask for red colour using inRange function
    mask = cv2.inRange(hsv, lower, upper)

    #Perform bitwise and on the original image arrays using the mask
    res = cv2.bitwise_and(cv_image, cv_image, mask=mask)
    
    #Font for text in video
    font = cv2.FONT_HERSHEY_SIMPLEX

    # Use putText() method for inserting text on video
    cv2.putText(res, self.str1, (50, 50), font, 1, (0, 255, 255), 2, cv2.LINE_4)
    cv2.putText(res, self.str2, (50, 80), font, 1, (0, 255, 0), 2, cv2.LINE_4)
  
    #Display the images
    cv2.imshow("Imagen original", cv_image)
    cv2.imshow("Resultado filtrado", res)
    cv2.waitKey(3)

    try:
      self.image_pub.publish(self.bridge.cv2_to_imgmsg(cv_image, "bgr8"))
    except CvBridgeError as e:
      print(e)

def main(args):
  rospy.init_node('image_converter', anonymous=True)
  
  ic = image_converter()
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)


